ZION ASSEMBLY UPDATED PORTAL

This package combines the welcome/passcode entry files from the all-in-one package with the multi-page Fire portal upgrade and the RCCG logo supplied by the user.

Upload the ZIP contents to the ROOT of the existing GitHub repository. Merge/replace files with the same names; do not delete the repository first. Keep the assets folder and assets/logo.png path intact. Preserve config.js and gate.js if your live repo has custom settings you need, and check those files before replacing them.

GitHub Pages is static hosting. Browser-local admin changes and front-end passcodes are not secure shared storage/authentication. This package does not publish itself; you must upload/commit the files to GitHub to update the live site.
