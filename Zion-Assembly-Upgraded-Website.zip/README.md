# Zion Assembly Church Resources
Upgraded static frontend for GitHub Pages.

## Important
The download links currently use placeholders (`#`). Real files need to be uploaded and linked.

For a real private admin upload system, use a proper backend/storage service rather than putting an admin password in browser JavaScript.